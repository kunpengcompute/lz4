/* *
 * Copyright (c) Huawei Technologies Co., Ltd. 2023-2023. All rights reserved.
 * Create: 2023-04
 */

#ifndef LZ4_ACCELERATER_H
#define LZ4_ACCELERATER_H

#include <arm_neon.h>
#include "stddef.h"
#define NO_PREFETCH
#define RAW_LZ4

#define G_KZLPRIME5BYTES (889523592379ULL)
#define G_KZLPRIME8BYTES (11400714785074694791ULL)

#ifndef KZL_FORCE_INLINE
#  ifdef _MSC_VER
#    define KZL_FORCE_INLINE static __forceinline
#  else
#    if defined (__cplusplus) || defined (__STDC_VERSION__) && __STDC_VERSION__ >= 199901L   /* C99 */
#      ifdef __GNUC__
#        define KZL_FORCE_INLINE static inline __attribute__((always_inline))
#      else
#        define KZL_FORCE_INLINE static inline
#      endif
#    else
#      define KZL_FORCE_INLINE static
#    endif
#  endif
#endif

#if defined(__GNUC__) && (__GNUC__ >= 4)
#    define KZL_MEMCPY_2(dst, src, size) __builtin_memcpy(dst, src, size)
#    define KZL_MEMCPY_4(dst, src, size) __builtin_memcpy(dst, src, size)
#    define KZL_MEMCPY_8(dst, src, size) vst1_u8((dst), vld1_u8(src))
#    define KZL_MEMCPY_16(dst, src, size) vst1q_u8((dst), vld1q_u8(src))
#    define KZL_MEMCPY_32(dst, src, size) vst1q_u8((dst), vld1q_u8(src)); vst1q_u8(((dst)+16), vld1q_u8(((src)+16)))
#    define KZL_MEMCPY_16X1(dst, src, size) vst1q_u64((dst), vld1q_u64(src))
#    define KZL_MEMCPY_32X1(dst, src, size) vst1q_u64((dst), vld1q_u64(src)); \
                vst1q_u64(((dst)+16), vld1q_u64(((src)+16)))
#endif

/* prefetch 321
 * can be disabled, by declaring NO_PREFETCH build macro */
#if defined(NO_PREFETCH)
#    define PREFETCH_L1(ptr)  (void)(ptr)  /* disabled */
#    define PREFETCH_L2(ptr)  (void)(ptr)  /* disabled */
#    define PREFETCH_L3(ptr)  (void)(ptr)  /* disabled */
#else
#  if defined(_MSC_VER) && (defined(_M_X64) || defined(_M_I86))  /* _mm_prefetch() is not defined outside of x86/x64 */
#    include <mmintrin.h>   /* https://msdn.microsoft.com/fr-fr/library/84szxsww(v=vs.90).aspx */
#    define PREFETCH_L1(ptr)  _mm_prefetch((const char*)(ptr), _MM_HINT_T0)
#    define PREFETCH_L2(ptr)  _mm_prefetch((const char*)(ptr), _MM_HINT_T1)
#    define PREFETCH_L2(ptr)  _mm_prefetch((const char*)(ptr), _MM_HINT_T2)
#  elif defined(__GNUC__) && ((__GNUC__ >= 4) || ((__GNUC__ == 3) && (__GNUC_MINOR__ >= 1)))
#    define PREFETCH_L1(ptr)  __builtin_prefetch((ptr), 1 /* rw==write */, 3 /* locality */)
#    define PREFETCH_L2(ptr)  __builtin_prefetch((ptr), 1 /* rw==write */, 2 /* locality */)
#    define PREFETCH_L3(ptr)  __builtin_prefetch((ptr), 1 /* rw==write */, 1 /* locality */)
#  elif defined(__aarch64__)
#    define PREFETCH_L1(ptr)  __asm__ __volatile__("prfm pldl1keep, %0" ::"Q"(*(ptr)))
#    define PREFETCH_L2(ptr)  __asm__ __volatile__("prfm pldl2keep, %0" ::"Q"(*(ptr)))
#    define PREFETCH_L3(ptr)  __asm__ __volatile__("prfm pldl3keep, %0" ::"Q"(*(ptr)))
#  else
#    define PREFETCH_L1(ptr) (void)(ptr)  /* disabled */
#    define PREFETCH_L2(ptr) (void)(ptr)  /* disabled */
#    define PREFETCH_L3(ptr) (void)(ptr)  /* disabled */
#  endif
#endif  /* NO_PREFETCH */

#define L1_CACHELINE_SIZE 64
#define L2_CACHELINE_SIZE 64
#define L3_CACHELINE_SIZE 128

#define PREFETCH_AREA_L1(p, s)  {            \
                const char* const ptr = (const char*)(p);  \
                size_t const size = (size_t)(s);     \
                size_t pos;                          \
                for (pos=0; pos<size; pos+=L1_CACHELINE_SIZE) {  \
                    PREFETCH_L1(ptr + pos);         \
                }                                     \
            }

#define PREFETCH_AREA_L2(p, s)  {            \
            const char* const ptr = (const char*)(p);  \
            size_t const size = (size_t)(s);     \
            size_t pos;                          \
            for (pos=0; pos<size; pos+=L2_CACHELINE_SIZE) {  \
                PREFETCH_L2(ptr + pos);         \
            }                                     \
        }

#define PREFETCH_AREA_L3(p, s)  {            \
            const char* const ptr = (const char*)(p);  \
            size_t const size = (size_t)(s);     \
            size_t pos;                          \
            for (pos=0; pos<size; pos+=L3_CACHELINE_SIZE) {  \
                PREFETCH_L3(ptr + pos);         \
            }                                     \
        }

enum PrefetchCpuCacheType {
    L1CACHE = 1,
    L2CACHE = 2,
    L3CACHE = 3
};

typedef enum PrefetchCpuCacheType CpuCacheType;

#define SEQUENCE_MOVE 24
#define HASH_SIZE 64

KZL_FORCE_INLINE uint32_t KZL_LittleEndianfastHash5(uint64_t sequence, uint8_t HashLogUsage)
{
    // for data ≤ 64KB
    return (uint32_t)(((sequence << SEQUENCE_MOVE) * G_KZLPRIME5BYTES) >> (HASH_SIZE - HashLogUsage));
}

KZL_FORCE_INLINE uint32_t KZL_BigEndianfastHash5(uint64_t sequence, uint8_t HashLogUsage)
{
    // for data > 64KB
    return (uint32_t)(((sequence >> SEQUENCE_MOVE) * G_KZLPRIME8BYTES) >> (HASH_SIZE - HashLogUsage));
}

void accerlerater(int srcSize, uint8_t *acceleration);
void skipTrigger(int srcSize, uint8_t *skipStep);
void PrefetchCpuCacheArea(const void* p, size_t s, CpuCacheType cacheType);

int PlatformIsSupport(void);

#endif
